# 运动与生成

## 观察到的推进

《贵州兴义》约 40.4 秒，看起来是一条连续镜头，没有明显硬切。画面不是“相机穿过风景”，而是“风景自己长出来，再自己收回去”：

| 时间（约） | 发生什么 | 可迁移的生成动作 |
| --- | --- | --- |
| 0–3s | 白纸、几条墨线、几粒色点 | `DRAW`：线先走，点后落 |
| 3–8s | 山体从线里长出来，飞鸟出现 | `DRAW` + `WASH_IN` |
| 8–14s | 青灰/土黄淡染铺开，树冠成点，云/雾留白 | `WASH_IN` + `SCATTER` |
| 14–19s | 圆形田块出现，屋顶落位 | `ASSEMBLE` |
| 19–24s | 向日葵从前景进入，田/村展开 | `SCATTER` + `ASSEMBLE` |
| 24–33s | 村落与田块稳定，向日葵移出 | `BREATHE` |
| 33–37s | 村落缩小，细节退回线 | `ERASE` |
| 37–40s | 只剩几笔线/一个小屋顶，回到白纸 | `ERASE` |

这些是视觉变化的描述，不是精确剪辑点。原片音轨未分析，不推断配乐、旁白或制作软件。

## 一条镜头只做一个动作

| 动作 | 时长 | 做什么 | 不做什么 |
| --- | --- | --- | --- |
| `DRAW` 线生长 | 4–6s | 一条墨线从边缘延伸，沿途带出山脊/路径 | 不要同时让屋顶出现 |
| `WASH_IN` 面铺开 | 4–6s | 灰/青/土黄从线的一侧晕开 | 不要同时撒点 |
| `SCATTER` 点散开 | 3–5s | 色点按簇出现，先密后疏 | 不要全屏均匀落点 |
| `ASSEMBLE` 模块拼装 | 5–7s | 屋顶逐个落位，窗格点阵亮起 | 不要同时让山移动 |
| `ERASE` 雾擦除 | 3–5s | 纸白从边缘擦回，细节退回线 | 不要突然白闪 |
| `BREATHE` 呼吸 | 5–8s | 完成帧只留雾/点/纸纹微动 | 不要镜头环绕 |

一条 5–8 秒镜头只选一个。长片用 3–4 条镜头，分别做 `DRAW` → `WASH_IN`/`SCATTER` → `ASSEMBLE` → `ERASE`，用雾/线/纸白衔接。

## 图生视频提示词

结构：

```text
[风格锁] + [首帧状态] + [一个生成动作] + [镜头] + [微动] + [稳定约束] + [负向]
```

中文示例（线生长）：

```text
暖米白宣纸上的吴冠中式点线面山水，焦墨线为骨，灰/青灰/土黄平涂为面，彩色点成簇，大面积留白，干笔飞白，手工印刷般的轻微套色错位。
首帧是一张几乎空白的纸，只有一条从右下角进入的淡墨线。
这条线在 5 秒内缓慢向左上延伸，像一条会走路的田埂；线经过的地方，两侧浮出 2–3 块青灰/土黄淡染，山脊用断续的墨线带出。
镜头极缓慢向前推近，幅度 2/10；纸纹、颗粒、留白保持稳定；不要出现屋顶、人物或文字。
负向：镜头翻滚，快速变焦，环绕，线分叉，点变成虫，墨线抖动，颜色闪烁，写实摄影，3D 渲染，随机文字，水印。
```

英文示例（模块拼装）：

```text
A Wu Guanzhong-inspired procedural landscape on warm rice paper. Calligraphic ink lines form the structure; flat gray, teal-gray and ochre washes form the planes; rhythmic color dots accent the scene; generous negative space, dry-brush edges, slight print misregistration.
The first frame is a quiet paper field with a winding path and two soft mountain washes.
Over six seconds, three to seven dark roof modules settle into the middle ground one by one; their window grids light up as small ink dots; a cluster of ochre dots gathers along the path.
The camera drifts forward very slowly, 2/10; the paper grain, palette and negative space stay stable. No people, no text, no camera roll.
Negative: morphing, extra roofs, jittering lines, flickering dots, rapid zoom, photorealistic, 3D render, text, watermark.
```

## 参数起始值

| 参数 | 建议 | 说明 |
| --- | --- | --- |
| 时长 | 5–8s | 越长越容易漂移 |
| 帧率 | 24fps | 电影感；不要 60fps 电视感 |
| 运动幅度 | 1–3 / 10 | 低运动是高级感与稳定性的前提 |
| 镜头 | 缓慢前推/横移，1 个方向 | 不要环绕、翻滚、快速变焦 |
| 首帧 | 必选 | 空白纸/score 图/风格化静帧 |
| 尾帧 | 有则更好 | 首尾帧能显著减少漂移 |
| 分辨率 | 1280–1920 宽 | 先低分辨率试运动，再放大 |
| 种子 | 固定 | 同系列复用 |

## 转场

只用四种，且要“像画”：

1. **线擦**：一条新墨线从画面一侧长出来，把上一景推走。
2. **面盖**：一块灰/青/土黄淡染从边缘铺满，下一景从面里显出。
3. **点散**：色点从焦点炸开，遮住切点，再落下成下一景的点。
4. **雾擦**：纸白/雾从边缘擦回，画面退回白纸，再起下一景。

不要用白闪、黑场、旋转、缩放模糊来掩盖不接。

## 稳定性

写进正向提示词：

- `stable paper texture, stable grain, stable palette`
- `one continuous ink line, no branching`
- `dots stay in clusters, no uniform scatter`
- `roof modules keep their count and position`
- `locked horizon, locked camera height`

负向词：

```text
morphing, melting, extra roofs, extra windows, branching lines, jittering lines, flickering dots, color shift, camera roll, rapid zoom, orbit, photorealistic, 3D render, glossy, text, watermark
```

## 失败修复

| 症状 | 修法 |
| --- | --- |
| 线分叉/抖动 | 降运动；缩短到 4s；写“one continuous line”；首帧只留一条线 |
| 点变成虫/雪花 | 降点预算；写“clusters, not uniform”；负向 insect/snow |
| 屋顶增殖/漂移 | 锁数量 3–7；缩短镜头；背景改留白；加尾帧 |
| 画面越来越满 | 用 `ERASE` 收尾；不要每帧加模块 |
| 颜色漂移 | 每镜写完整色板；后期统一 LUT；不要只写“彩色” |
| 像 PPT 平移 | 加墨线生长、雾流动、点微动；镜头只做极轻漂移 |
| 纸纹闪烁 | 固定种子；降运动；后期加稳定颗粒 |

## 声音方向（可选）

原片音轨未分析。若要声音，只用环境层：纸的摩擦、远处水声/鸟声、极轻的木鱼/风铃。不要加强节拍、合成器 Drop 或旁白；画面已经是“慢”的，声音不要抢。
