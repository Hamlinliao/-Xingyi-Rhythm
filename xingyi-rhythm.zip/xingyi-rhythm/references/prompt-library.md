# 提示词库

结构固定：**风格锁 → 主体锚点 → 抽象级别 → 构图 → 点线面预算 → 负向**。风格锁逐字复用，只换主体与构图。

## 1. 风格锁

### 中文·短版

```text
暖米白宣纸上的吴冠中式点线面山水。焦墨线为骨，提按、断连、飞白；灰、银灰、青灰、土黄平涂为面，边缘干笔；彩色点成簇，黄/红/绿/蓝不超过六种，红只做 1–3 簇；大面积留白，手工印刷般轻微套色错位，形式美与抽象美，但保留一个可读锚点。
```

### 中文·完整版

```text
暖米白宣纸上的吴冠中式点线面山水。以焦墨线建立骨架：一条主线贯穿画面，提按、断连、飞白，粗细随呼吸变化；灰、银灰、青灰、土黄以平涂/淡染形成 2–4 块大面，边缘干笔、可断可虚，不做写实光影与体积。彩色点成簇出现，黄、红、绿、蓝不超过六种，红只做 1–3 簇，像种子、窗灯、花盘与远处的人。留白占 40–65%，白是雾、水、天、气；允许手工印刷般的轻微套色错位与纸纤维颗粒。形式美、抽象美，但“风筝不断线”：保留 1–2 个可读锚点，让人认得出这是山水、村落、人物或器物。
```

### English · short

```text
A Wu Guanzhong-inspired procedural landscape on warm rice paper. Calligraphic ink lines form the structure with pressure, breaks and dry-brush edges; flat gray, silver-gray, teal-gray and ochre washes form two to four planes; rhythmic color dots cluster in yellow, red, green and blue, with red limited to one to three clusters; generous negative space, slight print misregistration, formal beauty and abstraction, but one or two readable anchors remain.
```

### English · full

```text
A Wu Guanzhong-inspired procedural landscape on warm rice paper. A single calligraphic ink line runs through the image, varying in pressure, breaking and reconnecting, with dry-brush ends; gray, silver-gray, teal-gray and ochre form two to four broad flat planes with soft, broken edges, no photoreal light or volume. Color dots gather in clusters — yellow, red, green, blue, no more than six colors, red limited to one to three clusters — like seeds, lit windows, flower heads or distant people. Negative space occupies 40–65%; white is mist, water, sky and air. Allow slight print misregistration and paper fibers. Formal beauty and abstraction, but keep the string of the kite: one or two readable anchors so the image still reads as landscape, village, figure or object.
```

## 2. 构图块

### 横向卷轴

```text
低地平线；两到四层山/田/雾横向叠压；一条弯曲的田埂或水带从画面下方进入，穿过田块，消失在山脚；留白在上部三分之一；村落偏右，树/点偏左配重。
```

### 中心岛

```text
主体/村落像一座岛，放在画面中偏左或偏右；四周留白 55–65%；一条线从岛边伸出，连到画面边缘；色点沿岛的边缘聚集，像水纹/灯火。
```

### 对角路径

```text
一条主路径从右下角进入，斜向左上；路径两侧分别是“密区”（村落/树/田）与“空区”（雾/水/纸白）；点沿路径由密到疏，把视线带到锚点。
```

### 网格田块

```text
俯视或斜俯视；把画面分成 2–4 组不规则田格，土黄/青灰/草绿交替；屋顶/树/人嵌在格子里；格子线不必闭合，允许断笔与留白。
```

## 3. 主体锚点

### 人像

```text
同一个人，保持同一张脸型、同一发型、同一副眼镜/疤痕/痣。L2 半抽象：脸用 2–3 条线勾轮廓、鼻线、下颌，脸颊用一块暖白/淡赭面；眼睛只留一个焦墨点 + 一条短横；头发是一整块焦墨，边缘飞白；衣服拆成 1–2 块大面，衣褶只留 1–2 条线，纽扣/胸针=2–3 个点。人物偏右，视线向左，左侧留白；背景一块灰/青灰淡染 + 2–4 簇色点，不要加马、祥云、印章。
```

### 宠物

```text
同一只 [橘猫/柴犬/…]，保持物种、耳形、尾形、毛色分区与眼睛颜色。L2：背线一条连续墨线，耳/尾 2–3 条短线；毛色用点簇分区（土黄/白/黑），不画每根毛；眼睛一个亮点 + 一个暗点。把它放大成主体，占画面 45–55%，坐在纸面上；旁边一个 4% 高的剪影人作为比例尺；背景一层淡灰 + 一簇草绿点。
```

### 产品

```text
同一件 [产品]，保持外形、比例、结构、logo 位置。L2：轮廓一条闭合但可断的线；体块 1–2 块平面（亮面=纸白，暗面=灰/品牌色）；按钮/刻度/缝线=点或短线；产品像一座“岛”放在低台/纸面上，四周留白 55%；背景一块淡青灰 + 3–5 簇色点；文字与 logo 后期合成，不生成。
```

### 建筑

```text
同一座建筑，保持屋顶轮廓、开间节奏、标志构件与朝向。L2：屋顶=三角/梯形模块 3–7 组，同一组朝向一致，组间可转 15–30°；墙=留白或极淡灰；窗=3–9 个点/短横；前景一枝树/一个挑担人压边；背景 2 块灰蓝山影 + 一条雾带。
```

### 风景

```text
同一片地景，保持山形、水岸线、村落位置与路径走向。L2：山=2–4 块灰蓝/青灰面，边缘干笔；田=2–5 组不规则网格，土黄/青灰/草绿；村=3–7 个屋顶模块 + 点阵窗；路=一条连续墨线从画面边缘进入，穿过田/村，消失在山脚；色点 120 个，红只留 1–2 簇。
```

### 群像/街拍

```text
同一组人，主人物保留脸部 2–3 条线与 1–2 块面；次要人物只做剪影/点，不画五官；前景 20–30% 用深色剪影/屋檐/树枝压边；中景是主人物与 2–3 个色点簇；背景一块淡灰 + 一条水平线；不要每个人都清楚。
```

## 4. 负向词

### 中文

```text
写实摄影，3D 渲染，塑料高光，镜面反射，HDR，镜头光晕，景深虚化，等宽描边，矢量填色，满屏彩点，均匀噪点，彩虹渐变，赛博霓虹，日式赛璐璐，游戏原画，过度锐化，随机文字，书法，印章，水印，边框，多余肢体，多指，多腿，脸融化，主体变形，装饰吞没主体
```

### English

```text
photorealistic, 3D render, plastic specular highlights, mirror reflection, HDR, lens flare, shallow depth of field, uniform outlines, vector fill, confetti everywhere, uniform noise, rainbow gradient, cyberpunk neon, Japanese cel animation, game concept art, over-sharpened, random text, calligraphy, seal stamp, watermark, border, extra limbs, extra fingers, extra legs, melting face, distorted subject, ornament swallowing the subject
```

## 5. 平台写法

### Midjourney

```text
/imagine prompt: [主体锚点] + [构图块] + [风格锁] --ar 16:9 --sref <风格图URL> --sw 150–300 --stylize 120–250 --no photo, 3d, text, watermark
```

- `--sref` 接风格图；`--sw` 控制风格强度，起始 150–300。
- 原图作 image prompt 时可用 `--iw 0.8–1.2`；不要堆太多参考图。
- 参数随版本变化，以当前版本为准。

### Stable Diffusion / ComfyUI

正向用完整版风格锁 + 主体锚点；图生图 0.45–0.6，Lineart 0.45–0.65，Depth 0.30–0.45；主体遮罩单独降强度。详见 [任意图片的转译](image-transfer.md)。

### 即梦 / 可灵 / 通义万相

图生图选“参考图/结构参考”，强度 0.45–0.65；风格参考另附静帧；主体描述放最前；负向词不支持时，把“no photo, no 3D, no text”写进正向句尾。

## 6. 完整示例

### 示例 A：贵州兴义风景

```text
暖米白宣纸上的吴冠中式点线面山水。焦墨线为骨，提按、断连、飞白；灰、银灰、青灰、土黄平涂为面，边缘干笔；彩色点成簇，黄/红/绿/蓝不超过六种，红只做 1–2 簇；留白 52%，手工印刷般轻微套色错位，形式美与抽象美，但保留可读锚点。

贵州兴义式层叠喀斯特峰丛与田园：三层山体，最近最暗、最远最淡；山=2–4 块灰蓝/青灰面；田=3 组不规则网格，土黄/青灰/草绿交替；村落偏右，3–7 个屋顶模块 + 点阵窗；一条连续田埂从右下进入，穿过田块，消失在山脚；左侧大面积纸白/雾；色点 120 个，沿田埂与树冠成簇，红只留 1 簇在屋顶/门洞。

构图：横向卷轴，低地平线；主体/村落占 35–45%，不要居中；留白在上部与左侧。
负向：写实摄影，3D 渲染，等宽描边，满屏彩点，彩虹渐变，随机文字，水印，过度锐化。
```

### 示例 B：人像

```text
暖米白宣纸上的吴冠中式点线面山水。焦墨线为骨，灰/青灰/土黄平涂为面，彩色点成簇，留白 55%，干笔飞白，轻微套色错位。

同一个年轻女子，保持圆脸、齐耳短发、圆框眼镜；L2 半抽象：脸用 3 条线勾轮廓/鼻线/下颌，脸颊一块暖白面；眼睛一个焦墨点 + 一条短横；头发一整块焦墨，边缘飞白；穿靛蓝立领长袍，衣服拆成 2 块面，衣褶 2 条线，纽扣 2 个点。人物偏右，视线向左；左侧留白；背景一块淡青灰 + 3 簇土黄/草绿点，不画五官、不加马、不加印章。

负向：写实摄影，3D 渲染，等宽描边，塑料高光，满屏彩点，随机文字，水印，脸崩，过度磨皮。
```

### 示例 C：产品

```text
暖米白宣纸上的吴冠中式点线面山水。焦墨线为骨，灰/青灰/土黄平涂为面，彩色点成簇，留白 58%，轻微套色错位。

同一只方形茶叶罐，保持外形、比例、金属盖结构、正面标签位置；L2：轮廓一条可断的线；体块 2 块平面（亮面纸白，暗面灰绿）；盖沿/接缝 2 条短线；标签留白，不生成文字。产品像一座岛放在低台/纸面上，占画面 40%，略偏右；左侧留白；背景一块淡青灰 + 4 簇土黄/红点；一条墨线从台前绕过，像水/路径。

负向：写实摄影，3D 渲染，塑料高光，镜面反射，改 logo，随机文字，水印，瓶身变形，多余结构。
```

### 示例 D：宠物

```text
暖米白宣纸上的吴冠中点线面。焦墨线为骨，灰/土黄/草绿平涂为面，彩色点成簇，留白 55%，干笔飞白。

同一只橘猫，保持物种、立耳、尾形、黄白毛色分区与琥珀色眼睛；L2：背线一条连续墨线，耳/尾 3 条短线；毛色用土黄/白点簇分区，不画每根毛；眼睛一个亮点 + 一个暗点。猫占画面 50%，坐在纸面偏左；右侧一个 4% 高的深色剪影人作为比例尺；背景一块淡青灰 + 2 簇草绿点；不要加鬃毛、不要换物种。

负向：写实摄影，3D 渲染，换物种，加鬃毛，多腿，满屏彩点，随机文字，水印。
```

## 7. 提示词卫生

- 一条提示词只用一个体系：不要“吴冠中 + 赛博 + 巴洛克 + 吉卜力”。
- 颜色写“角色”：焦墨是骨，灰是气，土黄是田，红是重音；不要只写“彩色”。
- 先写结构，再写风格形容词：留白多少、几条线、几块面、多少点、几个屋顶。
- 负向词不超过 40 个；太多会互相打架。
- 每次只改一个变量：抽象级别、留白、点预算、构图。
- 同一系列复用同一段风格锁、同一张纸纹、同一套色板；一致性来自重复。
