# 点线面语法

## 为什么先做 score

“程序化”不是让模型随机撒点，而是把一张图拆成**可替换的模块**：

1. 先决定哪里留白（`VOID`）。
2. 再决定哪条线走（`PATH` / `RIDGE`）。
3. 再决定哪几块面压住（`WASH` / `FIELD`）。
4. 最后用点、屋顶、窗格、树、鸟打节奏（`DOT` / `ROOF` / `WINDOW` / `TREE` / `BIRD`）。

同一张输入图，换 score 就能得到不同的构图；同一份 score，换渲染器就能得到不同的笔触。构图和渲染分开，才谈得上“程序化”。

## 画布与网格

- 画布默认 16:9；海报 4:5；短视频 9:16。
- 网格默认 **12 列 × 8 行**（横向）；竖版用 8×12。
- 所有坐标归一化到 `0..1`，原点左上。
- 每个格子只分配一个**主模块**，可以带 0–2 个**次模块**；不要一格塞五种东西。

## 模块表

| 模块 | 视觉 | 参数 | 数量 | 提示词短语 |
| --- | --- | --- | --- | --- |
| `VOID` | 不画，留纸白 | `area` 0.05–0.25 | 1–3 块 | warm paper negative space, mist, unpainted void |
| `PATH` | 一条会走路的墨线 | `width` 2–6, `curve` 0.2–0.8 | 1 主 + 0–2 次 | one continuous calligraphic path, winding ink line |
| `RIDGE` | 山脊/远山轮廓 | `breaks` 0.2–0.6 | 1–3 条 | broken ink ridge, mountain silhouette |
| `WASH` | 平涂/淡染的大面 | `opacity` 0.15–0.45 | 2–4 块 | flat mineral wash, soft-edged plane |
| `FIELD` | 不规则田块网格 | `rows` 2–4, `cols` 3–6 | 2–5 组 | irregular field patches, grid of ochre and teal |
| `ROOF` | 三角/梯形屋顶 | `count` 3–7, `scale` 0.02–0.08 | 3–7 组 | repeated roof modules, black tiled roofs, white walls |
| `WINDOW` | 窗格/门洞点阵 | `dots` 3–9 | 1–3 组 | window dot grid, small dark openings |
| `TREE` | 墨干 + 点冠 | `canopy` 8–40 dots | 1–3 组 | ink trunk, dotted canopy, sparse leaves |
| `DOT` | 彩色点簇 | `count` 40–200, `colors` 4–6 | 3–8 簇 | rhythmic color dots, seed-like accents |
| `BIRD` | 两三笔飞鸟 | `count` 1–3 | 1 组 | two or three V-shaped birds |
| `SUNFLOWER` | 放射状花盘 | `petals` 12–24 | 0–1 朵 | one sunflower, radial seed head |
| `MIST` | 擦白/雾带 | `width` 0.05–0.15 | 1–2 条 | soft mist band, erased paper edge |
| `TEXT` | 不生成 | — | 0 | 后期排版，不进模型 |

## 构图规则

1. **白先于黑**：先划出 40–65% 的 `VOID`，再放其他模块。不要把画面填满再擦白。
2. **一线到底**：一条 `PATH` 从画面边缘进入，穿过 2–3 个区域，最后消失或接屋顶；不要三条路互相打架。
3. **三面定调**：2–4 块 `WASH`/`FIELD` 决定画面的重量；最大的一块不超过画面 30%。
4. **屋顶成组**：3–7 个 `ROOF`，大小 2–3 个层级；同一组屋顶的朝向一致，组与组之间可以转 15–30°。
5. **点随线走**：`DOT` 沿 `PATH`、田埂、树冠、屋脊分布；不要均匀撒满。
6. **一红二黄三绿**：红色 1–3 簇，黄色 2–4 簇，绿色 1–3 簇；蓝可作远山/窗，不抢红。
7. **疏密对位**：密区（村落/树/田）旁边必须有一块大空区；不要把密区放正中。
8. **锚点唯一**：L2 只保留 1–2 个可读锚点（屋顶群、树、人脸、产品轮廓），其他都可以抽象。

## 参数旋钮

| 参数 | 默认 | 范围 | 低 | 高 |
| --- | --- | --- | --- | --- |
| `abstraction` | 0.55 | 0.25–0.85 | 更具体，细节多 | 更抽象，只剩符号 |
| `white_space` | 0.52 | 0.40–0.65 | 更满、更密 | 更空、更远 |
| `dot_budget` | 120 | 40–200 | 稀疏、安静 | 密集、节庆 |
| `line_energy` | 0.55 | 0.20–0.90 | 细、稳、少断 | 粗、快、飞白多 |
| `plane_count` | 3 | 2–4 | 轻、透 | 重、压 |
| `module_repeat` | 0.55 | 0.20–0.80 | 手绘、不规则 | 网格、程序感 |
| `accent_ratio` | 0.08 | 0.05–0.12 | 近乎黑白 | 色彩更响 |
| `seed` | 任意整数 | — | — | 同 seed 可复现 |

推荐组合：

- 人像/宠物：`abstraction 0.45 / white_space 0.55 / dot 80 / line 0.45 / repeat 0.35`
- 产品/建筑：`abstraction 0.50 / white_space 0.58 / dot 60 / line 0.40 / repeat 0.60`
- 风景：`abstraction 0.60 / white_space 0.50 / dot 140 / line 0.65 / repeat 0.55`
- 海报/艺术：`abstraction 0.75 / white_space 0.60 / dot 180 / line 0.75 / repeat 0.70`

## Score 结构

```json
{
  "schema": "xingyi-rhythm/score@1",
  "canvas": { "aspect": 1.78, "grid": [12, 8] },
  "seed": 20261106,
  "level": "L2",
  "palette": {
    "paper": "#E9E1D4",
    "ink": "#1F2422",
    "gray": "#8B9188",
    "accents": ["#D6B24C", "#B34532", "#2F7068", "#3F6F8E"]
  },
  "budgets": {
    "white_space": 0.52,
    "dot_budget": 120,
    "plane_count": 3,
    "line_count": 7,
    "accent_ratio": 0.08
  },
  "path": [[0.05, 0.92], [0.22, 0.74], [0.34, 0.62], [0.52, 0.55], [0.72, 0.42]],
  "regions": [
    { "id": "r03", "bbox": [0.0, 0.0, 0.35, 0.28], "module": "VOID", "weight": 0.9 },
    { "id": "r14", "bbox": [0.3, 0.3, 0.65, 0.62], "module": "WASH", "weight": 0.7 },
    { "id": "r22", "bbox": [0.55, 0.55, 0.9, 0.8], "module": "ROOF", "weight": 0.8 }
  ],
  "anchors": [
    { "x": 0.66, "y": 0.62, "module": "ROOF", "weight": 0.9 },
    { "x": 0.24, "y": 0.78, "module": "PATH", "weight": 0.8 }
  ]
}
```

字段说明：

- `palette` 是**目标风格色板**；`sampled_palette` 是从输入图采样的颜色，只作参考，不要直接当目标色。
- `white_space` 是风格目标（40–65%），`void_measured` 是原图实测留白；两者不是一回事。
- `path` 是主线路的归一化控制点；渲染时用样条/折线，不要画成直线。
- `regions[].bbox` 是 `[x0, y0, x1, y1]`；一个区域一个主模块。
- `anchors` 是必留锚点，优先级高于其他模块；生成时不能被装饰吞掉。
- `seed` 只用于打破平局（点的大小、屋顶的微差），不负责决定构图。

## 伪代码

```text
score = read_image_and_classify(input, grid=12x8)
score.palette = kmeans(input, k=6)
score.budgets = derive_budgets(score)
score.path = longest_edge_chain(score.regions)
score.anchors = top_weighted_regions(score, n=1..2)

canvas = paper(score.palette.paper)
for region in sort_by_weight(score.regions):
    if region.module == VOID: continue
    if region.module == WASH: draw_wash(region, opacity=0.2..0.4)
    if region.module == FIELD: draw_field_grid(region)
    if region.module == ROOF: draw_roof_group(region, count=3..7)
    if region.module == TREE: draw_tree(region)
draw_path(score.path, ink, width=2..6)
draw_dots(score.budgets.dot_budget, palette=score.palette.accents)
draw_mist(score.regions, erase=0.05..0.15)
```

## 从输入图得到 score

手工版（没有脚本时）：

1. 把图缩到 12×8 的缩略图，判断每格是“空/线/面/密”。
2. 找出最亮的 1–2 块 → `VOID`。
3. 找出最暗、最有结构的 1–3 块 → `ROOF` / `PATH` / `TREE`。
4. 找出最大面积的中间调 → `WASH` / `FIELD`。
5. 把高饱和的小块 → `DOT` 簇，集中在 2–4 个区域。
6. 画一条从边缘到主体的路径；路径必须经过至少两个区域。
7. 写下 1–2 个锚点，其他都可以删。

自动版：

```bash
python scripts/xingyi_score.py input.jpg --out score.json --preview score.png
```

脚本只做**分解与预算**，不做最终绘画；它输出 JSON、网格预览和提示词提示。不要把 score 预览当成成片。

## 视频里的“生成动作”

| 动作 | 做法 | 适用 |
| --- | --- | --- |
| 线生长 `DRAW` | 墨线从一端延伸到另一端，沿途带出山/田 | 开场、路径 |
| 面铺开 `WASH_IN` | 灰/青/黄从线的一侧晕开 | 山体、田块 |
| 点散开 `SCATTER` | 色点按簇出现，先密后疏 | 树冠、花、节日 |
| 模块拼装 `ASSEMBLE` | 屋顶/窗格逐个落位 | 村落、建筑 |
| 雾擦除 `ERASE` | 纸白从边缘擦回来 | 收尾、转场 |

一条 5–8 秒镜头只选一个动作；不要同时“线生长 + 点散开 + 屋顶拼装”。

## 程序化不等于随机

- 每个模块有数量、位置、颜色、大小约束；随机只在约束内发生。
- 先定 score，再渲染；不要边画边改构图。
- 同一系列复用 palette、paper texture、line width、dot size；变化只放在构图与密度。
- 保留 10–20% 的“手抖”：线不必完全平滑，点不必完全对齐，屋顶不必完全等大。完全规整会变成矢量插画，不是吴冠中。
