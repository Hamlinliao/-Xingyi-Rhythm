# xingyi_score.py

把一张图分解成“点线面”施工图，而不是生成成片。

```bash
pip install -r requirements.txt
python scripts/xingyi_score.py input.jpg \
  --out score.json \
  --preview score-preview.png \
  --grid 12x8 \
  --seed 20261106
```

输出：

- `score.json` — 色板、留白目标、点/线/面预算、主路径、锚点、12×8 模块网格、提示词提示。
- `score-preview.png` — 在原图上叠加网格、模块字母、主路径与锚点。**这是施工图，不是作品。**

模块字母：

| 字母 | 模块 | 含义 |
| --- | --- | --- |
| `·` | VOID | 留白/雾/纸 |
| `W` | WASH | 灰/青灰/土黄大面 |
| `F` | FIELD | 田块网格 |
| `L` | LINE | 墨线/路径/轮廓 |
| `R` | ROOF | 屋顶模块 |
| `T` | TREE | 树/植被 |
| `D` | DOT | 色点簇 |

注意：

- `palette` 是**目标风格色板**；`sampled_palette` 才是从原图采样的颜色。
- `white_space` 是**风格目标**（40–65%），不是原图的实测留白；`void_measured` 才是实测值。
- 分类是启发式的，不如图像模型懂语义。它给的是构图约束，不是最终答案。
- 脚本不渲染最终画面；把 `score.json` 的预算与 `prompts/` 的风格锁一起交给图像模型。
