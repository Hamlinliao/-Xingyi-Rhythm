#!/usr/bin/env python3
"""
xingyi_score.py — decompose an image into a Wu Guanzhong-inspired
point / line / plane score.

This is NOT a style-transfer renderer. It reads an image, estimates a
limited palette, divides the canvas into a grid, classifies each cell into
a visual module, and writes a JSON score plus an optional grid preview.

Dependencies: Pillow, numpy.

Example:
    python scripts/xingyi_score.py input.jpg \
        --out score.json --preview score-preview.png
"""

from __future__ import annotations

import argparse
import json
import math
import random
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw, ImageFilter, ImageFont, ImageOps

# ---------------------------------------------------------------------------
# constants
# ---------------------------------------------------------------------------

MODULE_COLORS = {
    "VOID": (255, 255, 255),
    "WASH": (150, 165, 160),
    "FIELD": (214, 178, 76),
    "LINE": (31, 36, 34),
    "ROOF": (31, 36, 34),
    "TREE": (79, 138, 87),
    "DOT": (179, 69, 50),
}

QUADRANTS = {
    "top-left": "upper left",
    "top-right": "upper right",
    "bottom-left": "lower left",
    "bottom-right": "lower right",
}

FALLBACK_PALETTE = {
    "paper": "#E9E1D4",
    "ink": "#1F2422",
    "gray": "#8B9188",
    "accents": ["#D6B24C", "#B34532", "#2F7068", "#3F6F8E"],
}

# The score targets the style palette, not the raw colors of the input photo.
STYLE_PALETTE = {
    "paper": "#E9E1D4",
    "ink": "#1F2422",
    "gray": "#8B9188",
    "accents": ["#D6B24C", "#B34532", "#2F7068", "#3F6F8E", "#4F8A57"],
}


# ---------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------

def clamp(value: float, low: float, high: float) -> float:
    return max(low, min(high, value))


def hex_color(rgb) -> str:
    r, g, b = [int(round(clamp(float(v), 0, 255))) for v in rgb[:3]]
    return f"#{r:02X}{g:02X}{b:02X}"


def luminance(rgb) -> float:
    r, g, b = [float(v) for v in rgb[:3]]
    return (0.2126 * r + 0.7152 * g + 0.0722 * b) / 255.0


def saturation(rgb) -> float:
    r, g, b = [float(v) for v in rgb[:3]]
    hi, lo = max(r, g, b), min(r, g, b)
    return 0.0 if hi == 0 else (hi - lo) / hi


def load_image(path: str, max_side: int = 1024) -> Image.Image:
    img = Image.open(path)
    img = ImageOps.exif_transpose(img).convert("RGB")
    if max(img.size) > max_side:
        scale = max_side / max(img.size)
        img = img.resize(
            (max(1, int(img.width * scale)), max(1, int(img.height * scale))),
            Image.LANCZOS,
        )
    return img


def kmeans_palette(img: Image.Image, k: int = 6, seed: int = 7):
    """Small k-means++ palette. Returns (centers, counts) sorted by count."""
    small = img.resize((120, 120), Image.BILINEAR)
    data = np.asarray(small, dtype=np.float64).reshape(-1, 3)
    rng = np.random.default_rng(seed)

    # k-means++ initialization
    centers = [data[rng.integers(0, len(data))]]
    for _ in range(1, k):
        d2 = np.min(
            ((data[:, None, :] - np.array(centers)[None, :, :]) ** 2).sum(axis=2),
            axis=1,
        )
        total = float(d2.sum())
        if total <= 0:
            centers.append(data[rng.integers(0, len(data))])
        else:
            probs = d2 / total
            centers.append(data[rng.choice(len(data), p=probs)])
    centers = np.array(centers, dtype=np.float64)

    labels = np.zeros(len(data), dtype=np.int32)
    for _ in range(14):
        distances = ((data[:, None, :] - centers[None, :, :]) ** 2).sum(axis=2)
        labels = distances.argmin(axis=1)
        for i in range(k):
            mask = labels == i
            if mask.any():
                centers[i] = data[mask].mean(axis=0)

    counts = np.bincount(labels, minlength=k)
    order = np.argsort(-counts)
    return centers[order], counts[order]


def pick_palette(img: Image.Image, seed: int = 7):
    try:
        centers, counts = kmeans_palette(img, k=6, seed=seed)
        total = max(1, int(counts.sum()))
        entries = []
        for center, count in zip(centers, counts):
            rgb = tuple(float(v) for v in center)
            entries.append(
                {
                    "rgb": rgb,
                    "hex": hex_color(rgb),
                    "count": int(count),
                    "ratio": count / total,
                    "lum": luminance(rgb),
                    "sat": saturation(rgb),
                }
            )

        paper = max(entries, key=lambda e: e["lum"] * 0.7 + e["ratio"] * 0.3)
        ink = min(entries, key=lambda e: e["lum"])
        rest = [e for e in entries if e is not paper and e is not ink]
        gray = min(rest, key=lambda e: abs(e["lum"] - 0.55)) if rest else paper
        accents = sorted(
            [e for e in rest if e is not gray and e["sat"] > 0.18],
            key=lambda e: e["sat"],
            reverse=True,
        )[:4]

        accent_hex = [e["hex"] for e in accents]
        if len(accent_hex) < 2:
            accent_hex = FALLBACK_PALETTE["accents"][:2]

        return {
            "paper": paper["hex"],
            "ink": ink["hex"],
            "gray": gray["hex"],
            "accents": accent_hex[:4],
        }
    except Exception:
        return dict(FALLBACK_PALETTE)


def edge_density(img: Image.Image) -> np.ndarray:
    gray = ImageOps.grayscale(img).filter(ImageFilter.GaussianBlur(0.6))
    edges = gray.filter(ImageFilter.FIND_EDGES)
    arr = np.asarray(edges, dtype=np.float64) / 255.0
    # Normalize by a high percentile so the score is not dominated by one edge.
    high = float(np.percentile(arr, 99))
    if high > 0:
        arr = np.clip(arr / high, 0, 1)
    return arr


def grid_features(img: Image.Image, edges: np.ndarray, cols: int, rows: int):
    w, h = img.size
    rgb = np.asarray(img, dtype=np.float64) / 255.0
    features = []
    for row in range(rows):
        row_features = []
        y0, y1 = int(row * h / rows), int((row + 1) * h / rows)
        for col in range(cols):
            x0, x1 = int(col * w / cols), int((col + 1) * w / cols)
            cell = rgb[y0:y1, x0:x1]
            mean_rgb = cell.reshape(-1, 3).mean(axis=0) * 255.0
            lum = float(luminance(mean_rgb))
            sat = float(saturation(mean_rgb))
            edge = float(edges[y0:y1, x0:x1].mean())
            row_features.append(
                {
                    "row": row,
                    "col": col,
                    "bbox": [x0, y0, x1, y1],
                    "rgb": [int(round(v)) for v in mean_rgb],
                    "lum": round(lum, 3),
                    "sat": round(sat, 3),
                    "edge": round(edge, 3),
                }
            )
        features.append(row_features)
    return features


def classify_cell(cell: dict) -> str:
    lum, sat, edge = cell["lum"], cell["sat"], cell["edge"]
    if lum > 0.82 and edge < 0.040:
        return "VOID"
    if edge > 0.110 and lum < 0.50:
        return "ROOF"
    if edge > 0.110 and sat > 0.30:
        return "TREE"
    if edge > 0.085:
        return "LINE"
    if sat > 0.30 and edge < 0.085:
        return "FIELD"
    if lum < 0.78:
        return "WASH"
    return "VOID"


def build_budgets(features, palette):
    flat = [cell for row in features for cell in row]
    n = max(1, len(flat))
    void_ratio = sum(1 for c in flat if c["module"] == "VOID") / n
    edge_mean = sum(c["edge"] for c in flat) / n
    sat_mean = sum(c["sat"] for c in flat) / n
    lum_mean = sum(c["lum"] for c in flat) / n

    dot_budget = int(clamp(40 + edge_mean * 260 + sat_mean * 120, 40, 200))
    line_count = int(clamp(4 + edge_mean * 22, 4, 12))
    plane_count = int(clamp(2 + (1 - void_ratio) * 5, 2, 4))
    accent_ratio = round(clamp(0.05 + sat_mean * 0.15, 0.05, 0.12), 3)
    abstraction = round(
        clamp(0.30 + (1 - edge_mean) * 0.35 + void_ratio * 0.25, 0.25, 0.85), 3
    )
    module_repeat = round(clamp(0.30 + (1 - sat_mean) * 0.40, 0.20, 0.80), 3)
    line_energy = round(clamp(0.30 + edge_mean * 0.80, 0.20, 0.90), 3)

    # The measured void ratio describes the input; the target is a style
    # constraint. A busy photo still gets a 40-65% paper target.
    white_space = round(clamp(0.42 + (1 - void_ratio) * 0.18, 0.40, 0.65), 3)

    return {
        "white_space": white_space,
        "void_measured": round(void_ratio, 3),
        "dot_budget": dot_budget,
        "line_count": line_count,
        "plane_count": plane_count,
        "accent_ratio": accent_ratio,
        "abstraction": abstraction,
        "module_repeat": module_repeat,
        "line_energy": line_energy,
        "edge_mean": round(edge_mean, 3),
        "sat_mean": round(sat_mean, 3),
        "lum_mean": round(lum_mean, 3),
    }


def pick_anchors(features, cols, rows, limit=3):
    flat = [cell for row in features for cell in row]
    module_bonus = {"ROOF": 0.30, "TREE": 0.18, "LINE": 0.06, "FIELD": 0.0}
    ranked = sorted(
        flat,
        key=lambda c: (
            c["edge"] * 1.0
            + c["sat"] * 0.3
            + (1 - c["lum"]) * 0.2
            + module_bonus.get(c["module"], 0.0)
        ),
        reverse=True,
    )
    picked = []
    for cell in ranked:
        if cell["module"] == "VOID":
            continue
        if any(
            abs(cell["col"] - p["col"]) <= 2 and abs(cell["row"] - p["row"]) <= 2
            for p in picked
        ):
            continue
        # Prefer module diversity for the first two anchors; fill the third freely.
        if len(picked) < 2 and any(p["module"] == cell["module"] for p in picked):
            continue
        picked.append(cell)
        if len(picked) >= limit:
            break

    anchors = []
    for cell in picked:
        module = cell["module"]
        if module in ("ROOF", "TREE", "LINE", "FIELD"):
            anchors.append(
                {
                    "x": round((cell["col"] + 0.5) / cols, 3),
                    "y": round((cell["row"] + 0.5) / rows, 3),
                    "module": module,
                    "weight": round(
                        clamp(cell["edge"] + cell["sat"] * 0.4, 0.1, 1.0), 3
                    ),
                }
            )
    return anchors


def build_path(features, cols, rows):
    """Greedy bottom-to-top path through high-edge cells."""
    points = []
    current_col = max(
        range(cols), key=lambda c: features[rows - 1][c]["edge"]
    )
    for row in range(rows - 1, -1, -1):
        candidates = [
            c
            for c in range(max(0, current_col - 2), min(cols, current_col + 3))
        ]
        best = max(candidates, key=lambda c: features[row][c]["edge"])
        points.append(
            [
                round((best + 0.5) / cols, 3),
                round((row + 0.5) / rows, 3),
            ]
        )
        current_col = best

    # If the image is nearly flat, fall back to a gentle S-curve.
    if len(points) < 3 or max(p[0] for p in points) - min(p[0] for p in points) < 0.1:
        points = [
            [0.12, 0.95],
            [0.28, 0.78],
            [0.42, 0.62],
            [0.58, 0.48],
            [0.72, 0.30],
        ]
    return [[round(p[0], 3), round(p[1], 3)] for p in chaikin(points, iterations=2)]


def chaikin(points, iterations=2):
    """Smooth a polyline; keeps the first and last points."""
    for _ in range(iterations):
        if len(points) < 2:
            break
        smoothed = [points[0]]
        for i in range(len(points) - 1):
            p, q = points[i], points[i + 1]
            smoothed.append([0.75 * p[0] + 0.25 * q[0], 0.75 * p[1] + 0.25 * q[1]])
            smoothed.append([0.25 * p[0] + 0.75 * q[0], 0.25 * p[1] + 0.75 * q[1]])
        smoothed.append(points[-1])
        points = smoothed
    return points


def quadrant_of(cells):
    if not cells:
        return "top-left"
    x = sum(c["col"] for c in cells) / len(cells)
    y = sum(c["row"] for c in cells) / len(cells)
    horizontal = "left" if x < 0.5 else "right"
    vertical = "top" if y < 0.5 else "bottom"
    return f"{vertical}-{horizontal}"


def build_hints(features, budgets, anchors, path):
    flat = [cell for row in features for cell in row]
    voids = [c for c in flat if c["module"] == "VOID"]
    quiet = quadrant_of(voids) if voids else "top-left"
    planes = budgets["plane_count"]
    dots = budgets["dot_budget"]
    lines = budgets["line_count"]
    red = 1 if budgets["accent_ratio"] <= 0.07 else 2
    anchors_text = ", ".join(f"{a['module']}@({a['x']:.2f},{a['y']:.2f})" for a in anchors)

    return [
        f"Start with {int(round(budgets['white_space'] * 100))}% paper; keep the {QUADRANTS[quiet]} as the quietest zone.",
        f"Place {planes} broad washes; keep the largest plane under 30% of the canvas.",
        f"Run one continuous ink path from ({path[0][0]:.2f},{path[0][1]:.2f}) to ({path[-1][0]:.2f},{path[-1][1]:.2f}); add {max(0, lines - 1)} secondary line groups.",
        f"Cluster about {dots} color dots in 3-5 groups; keep red to {red} cluster(s).",
        f"Protect the anchors: {anchors_text or 'one roof group, one tree'}.",
        "Keep 10-20% hand-wobble: lines break, dots vary in size, roofs are not identical.",
    ]


def preview_font(size: int):
    for name in (
        "DejaVuSans.ttf",
        "/System/Library/Fonts/Supplemental/Arial.ttf",
        "/System/Library/Fonts/Helvetica.ttc",
    ):
        try:
            return ImageFont.truetype(name, size)
        except Exception:
            continue
    try:
        return ImageFont.load_default(size=size)
    except TypeError:
        return ImageFont.load_default()


def draw_preview(img: Image.Image, score: dict, out_path: str):
    w, h = img.size
    base = Image.blend(img.convert("RGB"), Image.new("RGB", img.size, (255, 255, 255)), 0.55).convert("RGBA")
    overlay = Image.new("RGBA", img.size, (0, 0, 0, 0))
    draw = ImageDraw.Draw(overlay)

    cols, rows = score["canvas"]["grid"]
    cell_w, cell_h = w / cols, h / rows
    font_cell = preview_font(max(12, w // 80))
    font_legend = preview_font(max(13, w // 65))

    for row in range(rows):
        for col in range(cols):
            cell = score["cells"][row][col]
            module = cell["module"]
            color = MODULE_COLORS.get(module, (255, 255, 255))
            x0, y0 = col * cell_w, row * cell_h
            x1, y1 = x0 + cell_w, y0 + cell_h
            if module != "VOID":
                draw.rectangle([x0, y0, x1, y1], fill=color + (26,))
            draw.rectangle([x0, y0, x1, y1], outline=(31, 36, 34, 55), width=1)
            label = {
                "VOID": "·",
                "WASH": "W",
                "FIELD": "F",
                "LINE": "L",
                "ROOF": "R",
                "TREE": "T",
                "DOT": "D",
            }.get(module, "?")
            draw.text(
                (x0 + 4, y0 + 3),
                label,
                fill=(31, 36, 34, 170),
                font=font_cell,
            )

    # path
    pts = [(p[0] * w, p[1] * h) for p in score["path"]]
    if len(pts) >= 2:
        draw.line(pts, fill=(179, 69, 50, 210), width=max(2, w // 400), joint="curve")

    # anchors
    for anchor in score["anchors"]:
        x, y = anchor["x"] * w, anchor["y"] * h
        r = max(8, w // 110)
        draw.ellipse([x - r, y - r, x + r, y + r], outline=(179, 69, 50, 230), width=max(2, w // 500))
        draw.ellipse([x - 3, y - 3, x + 3, y + 3], fill=(179, 69, 50, 255))

    # legend
    legend_h = max(48, h // 14)
    draw.rectangle([0, h - legend_h, w, h], fill=(233, 225, 212, 235))
    legend = (
        f"VOID {int(round(score['budgets']['white_space'] * 100))}%  "
        f"DOTS {score['budgets']['dot_budget']}  "
        f"LINES {score['budgets']['line_count']}  "
        f"PLANES {score['budgets']['plane_count']}  "
        f"ABSTRACTION {score['budgets']['abstraction']:.2f}  "
        f"SEED {score['seed']}"
    )
    draw.text(
        (12, h - legend_h + legend_h // 2 - 6),
        legend,
        fill=(31, 36, 34, 230),
        font=font_legend,
    )

    composed = Image.alpha_composite(base, overlay).convert("RGB")
    composed.save(out_path, quality=92, optimize=True)


def build_score(img: Image.Image, cols: int, rows: int, seed: int):
    sampled_palette = pick_palette(img, seed=seed)
    palette = dict(STYLE_PALETTE)
    edges = edge_density(img)
    features = grid_features(img, edges, cols, rows)
    for row in features:
        for cell in row:
            cell["module"] = classify_cell(cell)
    budgets = build_budgets(features, palette)
    anchors = pick_anchors(features, cols, rows)
    path = build_path(features, cols, rows)
    hints = build_hints(features, budgets, anchors, path)

    # Convert bbox pixels to normalized values for the JSON.
    w, h = img.size
    cells = []
    for row in features:
        out_row = []
        for cell in row:
            x0, y0, x1, y1 = cell["bbox"]
            out_row.append(
                {
                    "module": cell["module"],
                    "bbox": [
                        round(x0 / w, 3),
                        round(y0 / h, 3),
                        round(x1 / w, 3),
                        round(y1 / h, 3),
                    ],
                    "lum": cell["lum"],
                    "sat": cell["sat"],
                    "edge": cell["edge"],
                }
            )
        cells.append(out_row)

    return {
        "schema": "xingyi-rhythm/score@1",
        "source": Path(img.filename).name if getattr(img, "filename", None) else "input",
        "canvas": {
            "width": img.width,
            "height": img.height,
            "aspect": round(img.width / img.height, 3),
            "grid": [cols, rows],
        },
        "seed": seed,
        "level": "L2",
        "palette": palette,
        "sampled_palette": sampled_palette,
        "budgets": budgets,
        "path": path,
        "anchors": anchors,
        "cells": cells,
        "prompt_hints": hints,
        "notes": [
            "This is a composition score, not a finished artwork.",
            "Module letters: VOID=paper, WASH=plane, FIELD=field grid, LINE=line, ROOF=roof, TREE=tree, DOT=dot cluster.",
            "Use the palette and budgets as constraints, not as a pixel-perfect target.",
        ],
    }


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def parse_grid(value: str):
    try:
        cols, rows = value.lower().split("x")
        return int(cols), int(rows)
    except Exception as exc:
        raise argparse.ArgumentTypeError("grid must look like 12x8") from exc


def main():
    parser = argparse.ArgumentParser(
        description="Decompose an image into a Wu Guanzhong-inspired point/line/plane score."
    )
    parser.add_argument("input", help="input image path")
    parser.add_argument("--out", default="score.json", help="output JSON path")
    parser.add_argument("--preview", default="", help="optional preview PNG path")
    parser.add_argument("--grid", type=parse_grid, default=(12, 8), help="grid, e.g. 12x8")
    parser.add_argument("--seed", type=int, default=20261106, help="seed for palette and hints")
    parser.add_argument("--max-side", type=int, default=1024, help="max image side for analysis")
    args = parser.parse_args()

    img = load_image(args.input, max_side=args.max_side)
    cols, rows = args.grid
    score = build_score(img, cols, rows, args.seed)
    score["source"] = Path(args.input).name

    Path(args.out).parent.mkdir(parents=True, exist_ok=True)
    with open(args.out, "w", encoding="utf-8") as fh:
        json.dump(score, fh, ensure_ascii=False, indent=2)

    if args.preview:
        Path(args.preview).parent.mkdir(parents=True, exist_ok=True)
        draw_preview(img, score, args.preview)

    print(
        f"wrote {args.out} | grid {cols}x{rows} | "
        f"void {score['budgets']['white_space']:.2f} | "
        f"dots {score['budgets']['dot_budget']} | "
        f"lines {score['budgets']['line_count']} | "
        f"planes {score['budgets']['plane_count']}"
    )
    if args.preview:
        print(f"wrote {args.preview}")


if __name__ == "__main__":
    main()
