# Preview assets

## From the original work

These files contain stills or derived previews from the interactive work 《贵州兴义》 by Liao Huimin (Hamlin). They are licensed under **CC BY-NC 4.0**: non-commercial sharing and adaptation with attribution; commercial use requires separate permission.

- `still-01.jpg` — blank paper, one winding line, first dots
- `still-02.jpg` — circular field grid and a single pavilion
- `still-03.jpg` — village, fields, path, dot clusters
- `still-04.jpg` — sunflower and circular field
- `still-05.jpg` — village dissolving back into paper
- `still-06.jpg` — ink mountains, cloud/mist and a yellow tree
- `cover.jpg` — README cover, using `still-03`
- `contact-sheet.jpg` — six-step generation sequence
- `grammar.jpg` — point / line / plane crops and rules
- `score-demo.png` — grid/score overlay on `still-03`
- `motion-preview.gif` — ~4s motion sample

## Generated diagrams

These are original diagrams created for this skill and released under the **MIT License**:

- `palette.png` — palette and area-ratio card
- `icon.png` — skill icon

The original video is not included in this repository.
